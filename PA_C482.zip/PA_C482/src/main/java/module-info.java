module thomasmccue.pa_c482 {
    requires javafx.controls;
    requires javafx.fxml;


    opens thomasmccue.pa_c482 to javafx.fxml;
    exports thomasmccue.pa_c482;
}